<?php /* C:\xampp\htdocs\projectpsm\resources\views/sprint/index.blade.php */ ?>
<?php $__env->startSection('article'); ?>
    <ul>
       <li class="aside a"><a href="<?php echo e(route('sprints.index')); ?>">Sprint</a></li>
        
    <li class="aside a"><a href="<?php echo e(route('userstory.index')); ?>">User Stories</a></li>
        <li class="aside a"><a href="#contact">Logout</a></li>
    </ul>
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>
<?php echo csrf_field(); ?>

    
<?php $__currentLoopData = $sprints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sprint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="<?php echo e(route('sprints.edit', [$sprint])); ?>">
             <?php echo e($sprint->sprint_name); ?> 
            </a>
                     
        </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
<?php if($sprints->isEmpty()): ?>
<br><br>
     No sprint.
<?php endif; ?>

<br><br><br>
<button type="submit"><a href="<?php echo e(route('sprints.create')); ?>">Create Sprint</a></button>
   
<?php $__env->stopSection(); ?>


          
<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>