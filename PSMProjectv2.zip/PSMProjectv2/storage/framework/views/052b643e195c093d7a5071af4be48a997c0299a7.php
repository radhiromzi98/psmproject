<?php /* C:\xampp\htdocs\projectpsm\resources\views/secfeature/create.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<br><br><br>
<form action="<?php echo e(route('secfeature.store')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
 Security Feature Name :<input type="text" name="secfeature_name" style="margin-left:2.5em">
<br><br><br>
 Description :<input type="text" name="secfeature_desc" style="margin-left:2.6em" height="10" width="20">
 <br><br><br>

 <button type="submit">Save</button>
 <button type="submit"><a href="<?php echo e(route('secfeature.index')); ?>">Cancel</a></button>
 <br><br><br>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>