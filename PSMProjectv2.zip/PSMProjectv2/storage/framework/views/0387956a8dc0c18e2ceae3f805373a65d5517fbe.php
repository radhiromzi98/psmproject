<?php /* C:\xampp\htdocs\PSMProjectv2\resources\views/secfeature/create.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<br><br><br>
<form action="<?php echo e(route('secfeature.store')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
 Security Feature Name :<input type="text" name="secfeature_name" style="margin-left:2.5em">
 <div class="error"><font color="red" size="2"><?php echo e($errors->first('secfeature_name')); ?></font></div>
<br><br><br>

 Description :<input type="text" name="secfeature_desc" style="margin-left:2.6em" height="30" width="70">
 <div class="error"><font color="red" size="2"><?php echo e($errors->first('secfeature_desc')); ?></font></div>
 <br><br><br>

 <button type="submit">Save</button>
 <button type="submit"><a href="<?php echo e(route('secfeature.index')); ?>">Cancel</a></button>
 <br><br><br>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>