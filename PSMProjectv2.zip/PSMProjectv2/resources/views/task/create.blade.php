@extends('layouts.app1')

@section ('content')
<form action="">
Assign Task :
<br><br><br>
Member Name :

    

<br><br><br>
Role :

<select name="role" class="form-control">
    <option>--Select Role--</option>
    @foreach($roles as $role)
        <option value="{{ $role->role_name }}">
            {{ $role->role_name }}
        </option>
    @endforeach
</select>
<br><br><br>
<button type="submit">Add Task</button>
@endsection

</form>

