@extends('layouts.app1')

@section('content')
@foreach($tasks as $task)
        <li>
            <a href="{{ route('tasks.edit', [$task]) }}">
             {{ $tasks->task }} 
            </a>
                     
        </li>
@endforeach
        
@if($tasks->isEmpty())
<br><br>
     No task assign.
@endif