@extends('layouts.app2')
<style>
        table {
          font-family: arial, sans-serif;
          border-collapse: collapse;
          width: 100%;
        }
        
        td, th {
          border: 1px solid #dddddd;
          text-align: left;
          padding: 8px;
        }
        
        tr:nth-child(even) {
          background-color: #dddddd;
        }
</style>

@section('dashboard')

@foreach($projects as $project)
        <li>
            <a href="{{ route('projects.edit', [$project]) }}">
             {{ $project->proj_name }} 
            </a>
                     
        </li>
@endforeach
        
@if($projects->isEmpty())
     No project.
@endif
                    

@endsection


@section('content')
<br><br><br>
<table>
<tr>
    <th>Code ID</th>
    <th>Coding Standard Title</th>
    
</tr>

@foreach($codestands as $codestand)
<tr> 
    <th>
            {{ $codestand->codestand_id }}
    </th>

    <th>
            {{ $codestand->codestand_name }}
    </th>

    <th>
     
    </th>
</tr>
@endforeach
</table>
<br><br><br>

<button type="submit"><a href="{{route('codestand.create')}}">Add Coding Standard</a></button>

@endsection