@extends('layouts.app2')

@section('dashboard')

@foreach($projects as $project)
        <li>
            <a href="{{ route('projects.edit', [$project]) }}">
             {{ $project->proj_name }} 
            </a>
                     
        </li>
@endforeach
        
@if($projects->isEmpty())
     No project.
@endif
@endsection

@section('content')
<br><br><br>
<form action="{{route('userstory.store')}}" method="post" enctype="multipart/form-data">
        @csrf



    Sprint ID: <input type="text" name="sprint_id" 
        value=<?php use App\Http\Controllers\UserStoryController;
        echo UserStoryController::getID(); ?>
    ></input>

  
     <br><br><br>   
     
    User Story : <textarea id = "user_story"
        rows = "2"
        cols = "100"
        name="user_story" ></textarea>
    
    <br><br><br>

    Description : <textarea id = "user_story"
    rows = "2"
    cols = "100"
    name="desc_story"></textarea>

    <br><br><br>
    
    Priority : 
    <select name="prio_story">
        @foreach($prios as $prio)
        <option value="{{ $prio->prio_name}}" {{ ((isset($prio->prio_name) && $prio->prio_name== $prio->prio_name)? "selected":"") }}>{{$prio->prio_name}}</option>
        @endforeach
        
    </select>

    <br><br><br>
    State : 
    <select name="workflow">
        @foreach($workflows as $workflow)
        <option value="{{ $workflow->workflow_name}}" {{ ((isset($workflow->workflow_name) && $workflow->workflow_name== $workflow->workflow_name)? "selected":"") }}>{{$workflow->workflow_name}}</option>
        @endforeach
        
    </select>
    <br><br><br>

    @csrf
    
    Security Feature : 
  
  </select>
  <br><br><br>
  @foreach($secfeatures as $secfeature)
  <label class="checkbox-inline">
  <input type="checkbox" id="secfeature_id" name="secfeature_id[]" value="{{$secfeature->secfeature_id}}"> {{$secfeature->secfeature_name}}
  </label>
  @endforeach

  <br><br><br>


    Performance Feature : 
  </select>
  <br><br><br>
  @foreach($perfeatures as $perfeature)
  <label class="checkbox-inline">
  <input type="checkbox" id="perfeature_id" name="perfeature_id[]" value="{{$perfeature->perfeature_id}}"> {{$perfeature->perfeature_name}}
  </label>
  @endforeach 
  <br><br><br>


        <button type="submit">Add Story</button>
        <button type="submit"><a href="{{route('userstory.index')}}", method="post">Cancel</a></button>
   
    </form>
    <br><br><br>
@endsection
