@extends('layouts.app2')

@section('dashboard')

@foreach($projects as $project)
        <li>
            <a href="{{ route('projects.edit', [$project]) }}">
             {{ $project->proj_name }} 
            </a>
                     
        </li>
@endforeach
        
@if($projects->isEmpty())
     No project.
@endif
@endsection

@section('content')
<br><br><br>
<form action="{{route('deffeature.store')}}" method="post" enctype="multipart/form-data">
        @csrf
        
    User Story : <textarea id = "user_story"
        rows = "2"
        cols = "100"
        name="user_story"></textarea>
    
    <br><br><br>

    Description : <textarea id = "user_story"
    rows = "2"
    cols = "100"
    name="desc_story"></textarea>

    <br><br><br>

    Priority : 
    <select name="prio_story">
        @foreach($prios as $prio)
        <option value="{{ $prio->prio_name}}" {{ ((isset($prio->prio_name) && $prio->prio_name== $prio->prio_name)? "selected":"") }}>{{$prio->prio_name}}</option>
        @endforeach
        
    </select>

    <br><br><br>
    State : 
    <select name="workflow">
        @foreach($workflows as $workflow)
        <option value="{{ $workflow->workflow_name}}" {{ ((isset($workflow->workflow_name) && $workflow->workflow_name== $workflow->workflow_name)? "selected":"") }}>{{$workflow->workflow_name}}</option>
        @endforeach
        
    </select>
    <br><br>
    
        <button type="submit">Add Defect</button>
        <button type="submit"><a href="{{route('userstory.index')}}", method="post">Cancel</a></button>
   
    </form>
    <br><br><br>
@endsection
