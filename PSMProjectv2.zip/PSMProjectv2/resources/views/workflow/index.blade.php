@extends('layouts.app2')
<style>
        table {
          font-family: arial, sans-serif;
          border-collapse: collapse;
          width: 100%;
        }
        
        td, th {
          border: 1px solid #dddddd;
          text-align: left;
          padding: 8px;
        }
        
        tr:nth-child(even) {
          background-color: #dddddd;
        }
</style>

@section('dashboard')

@foreach($projects as $project)
        <li>
            <a href="{{ route('projects.edit', [$project]) }}">
             {{ $project->proj_name }} 
            </a>
                     
        </li>
@endforeach
        
@if($projects->isEmpty())
     No project.
@endif
                    

@endsection

@section('content')
<br><br><br>
<table>
<tr>
    <th> ID </th>
    <th> State Name </th>
    <th> Edit </th>
</tr>

@foreach($workflows as $workflow)
<tr> 
    <th>
            {{ $workflow->wflow_id }}
    </th>

    <th>
            {{ $workflow->workflow_name }}
    </th>

    <th>
      <a href="{{route('workflow.edit', $workflow)}}">
        Edit</th>

    
</tr>
@endforeach
</table>
<br><br><br>
<button type="submit"><a href="{{route('workflow.create')}}">Add Workflow Step</a></button>

@endsection