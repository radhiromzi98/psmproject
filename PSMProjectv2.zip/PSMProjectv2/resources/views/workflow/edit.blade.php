@extends('layouts.app2')

@section('dashboard')

@foreach($projects as $project)
        <li>
            <a href="{{ route('projects.edit', [$project]) }}">
             {{ $project->proj_name }} 
            </a>
                     
        </li>
@endforeach
@endsection

@section('content')
<br><br><br>
<form action="{{route('workflow.update',$workflow)}}" method="post" enctype="multipart/form-data">
@csrf
 State Name :<input type="text" name="workflow_name" style="margin-left:2.5em">
<br><br><br>
 

 <button type="submit">Save</button>
 <button type="submit"><a href="{{route('workflow.index')}}">Cancel</a></button>
 <br><br><br>
 @endsection