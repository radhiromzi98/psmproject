<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WorkflowStep extends Model
{
    //
}
