<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PerformanceFeature extends Model
{
    public $foreignkey = 'perfeature_id';
}
