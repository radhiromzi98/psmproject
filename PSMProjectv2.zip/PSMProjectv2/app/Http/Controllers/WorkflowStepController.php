<?php

namespace App\Http\Controllers;
use App\Project;
use App\WorkflowStep;
use Illuminate\Http\Request;

class WorkflowStepController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $project = new Project;
        if (\Auth::check())
        {
            $id = \Auth::user()->getId();
            
        }
        if($id)
        {
            $pro = \App\Project::where('user_id', '=', $id)->get();
            //return view('profeature.index',['projects'=>$project, 'pros'=>$pro]);
        }
        
        $workflow = new WorkflowStep;
        return view('workflow.index',['workflows'=>$workflow->all(), 'projects'=>$project->all()]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $project = new Project;
        return view('workflow.create')->with('projects',$project->all());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $workflow = new WorkflowStep;

        $workflow->workflow_name=$request->workflow_name;
        $workflow->save();
        return redirect()->route('workflow.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\WorkflowStep  $workflowStep
     * @return \Illuminate\Http\Response
     */
    public function show(WorkflowStep $workflowStep)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\WorkflowStep  $workflowStep
     * @return \Illuminate\Http\Response
     */
    public function edit(WorkflowStep $workflowStep)
    {
        return view('workflow.edit');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\WorkflowStep  $workflowStep
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, WorkflowStep $workflowStep)
    {
        $workflow = new WorkflowStep;
        $workflow->workflow_name=$request->workflow_name;
        $workflow->save();
        return redirect()->route('workflow.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\WorkflowStep  $workflowStep
     * @return \Illuminate\Http\Response
     */
    public function destroy(WorkflowStep $workflowStep)
    {
        //
    }
}
