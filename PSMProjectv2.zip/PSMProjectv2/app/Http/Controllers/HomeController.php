<?php

namespace App\Http\Controllers;
use App\Project;
use Illuminate\Http\Request;
use App\User;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $project = new Project;
        //$projects = $user->project;
        //$projects = $project->all();
      
        return view('home')->with (['projects' => $project->all()]);
    }

    public function create()
    {
        return view('project.create');
    }

    public function update(Request $request,Project $project)
    {
        $project->proj_name=$request->proj_name;
        $project->proj_desc=$request->proj_desc;
        $project->start_date=$request->start_date;
        $project->end_date=$request->end_date; 
        $project->save(); 
    
        return redirect()->route('projects.index', $project);
    }

    public function edit(Project $project)
    {
        return view('project.edit')->with('project', $project);;
    }

    public function show(Project $project)
    {
        $project = new Project;
        return view('project.index')->with('project', $project);;

    }
}
