<?php

namespace App\Http\Controllers;
use App\Mapping;
use App\Project;
use App\WorkflowStep;
use App\SecurityFeature;
use App\PerformanceFeature;
use App\UserStory;
use Illuminate\Http\Request;

class MappingController extends Controller
{
    public function destroy(Mapping $map, UserStory $userstory)
    {
        $map->delete();
        $project = new Project;
        $workflow = new WorkflowStep;
        $secfeature = new SecurityFeature;
        $perfeature = new PerformanceFeature;
        $map = new Mapping;
        $secfeatures = $secfeature->select('secfeature_name')->get();
        $perfeatures = $perfeature->select('perfeature_name')->get();
        return view('userstory.edit',['maps'=>$map->all(),'secfeatures'=>$secfeature->all(), 'perfeatures'=>$perfeature->all(),'workflows'=>$workflow->all(),'userstory'=>$userstory, 'projects'=>$project->all()]);
    }
}
