<?php

namespace App\Http\Controllers;
use App\Priority;
use App\UserStory;
use App\WorkflowStep;
use App\SecurityFeature;
use App\PerformanceFeature;
use App\Project;
use App\Mapping;
use App\Sprint;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;



class UserStoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        $project = new Project;
        if (\Auth::check())
        {
            $id = \Auth::user()->getId();
            
        }
        if($id)
        {
            $pro = \App\Project::where('user_id', '=', $id)->get();
            return view('profeature.index',['projects'=>$project, 'pros'=>$pro]);
        }
        
        $userstory = new UserStory;
        return view('userstory.index',['userstories'=>$userstory->all(),'projects'=>$project->all()]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public static function getID()
    {
        $parameters = \Request::segment(3);
        return $parameters;
    }

    public static function getID2()
    {
        $parameters = \Request::segment(2);
        return $parameters;
    }
    
    public function create(Userstory $sprint_id)
    {
        Route::currentRouteName();
        $sprint = Sprint::all();
        //$userstory = UserStory::find($request->sprint_id);        
        $workflow = new WorkflowStep;
        $prio = new Priority;
        $project = new Project;
        $secfeature = new SecurityFeature;
        $perfeature = new PerformanceFeature;
        $prios = $prio->select('prio_name')->get();
        $secfeatures = $secfeature->select('secfeature_name')->get();
        $perfeatures = $perfeature->select('perfeature_name')->get();
        
        
        
        //$sprint_id = $request->sprint_id;
        $sprint = Sprint::where('sprint_id', '=', "$sprint_id")->get();
        return view('userstory.create',compact('sprint_id'),['proj_name','perfeatures'=> $perfeature->all(),'prios'=> $prio->all(), 'secfeatures'=> $secfeature->all(), 'projects'=>$project->all(),'workflows'=>$workflow->all(), 'sprint'=>$sprint_id]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $project = Project::all();
        $userstory = new UserStory();
        $userstory->user_story = $request->user_story;
        $userstory->desc_story = $request->desc_story;
        $userstory->prio_story = $request->prio_story;
        $userstory->workflow = $request->workflow;
        $sprint= new Sprint();
        /*$sprint = Sprint::where('sprint_id', '=', $sprint_id)
        ->select('sprint_id')->first();*/
        $userstory->sprint_id = $request->sprint_id;
        $userstory->save();
    
        
        $mapping = new Mapping();
        $mapping = UserStory::where('u_id', '=', 'u_id')->get();
        if($mapping)
            {
                foreach($mapping as $value)
                {
                    $value->ustory_id=$request->u_id;
                    $value->type_NFR= 1;
                    $value->id_NFR=$request->SecFeature_id; 
                    $value->save();
                }

                if ($mapping)
                {
                    foreach($mapping as $value)
                    {
                        $value->ustory_id=$request->u_id;
                        $value->type_NFR= 2;
                        $value->id_NFR=$request->perfeature_id;
                        $value->save(); 
                     }
                }
            }
            

        

        $sprint_id = $request->sprint_id;
        $userstory = UserStory::where('sprint_id', '=', "$sprint_id")->get();
        return view('profeature.index3',['userstories'=>$userstory, 'projects'=>$project]);
           
    }
    
    /**
     * Display the specified resource.
     *
     * @param  \App\UserStory  $userStory
     * @return \Illuminate\Http\Response
    */
        
    public function show(UserStory $userStory)
    {
       //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\UserStory  $userStory
     * @return \Illuminate\Http\Response
     */
    public function edit(UserStory $userstory, $id =[])
    {
        //$project = new Project;
        //return view('userstory.edit',['userstory'=>$userStory,'projects'=>$project->all()]);
        $project = new Project;
        $workflow = new WorkflowStep;
        $secfeature = new SecurityFeature;
        $perfeature = new PerformanceFeature;
        $map = new Mapping;
        $secfeatures = $secfeature->select('secfeature_name')->get();
        $perfeatures = $perfeature->select('perfeature_name')->get();
       
        return view('userstory.edit',['maps'=>$map->all(),'secfeatures'=>$secfeature->all(), 'perfeatures'=>$perfeature->all(),'workflows'=>$workflow->all(),'userstory'=>$userstory, 'projects'=>$project->all()]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\UserStory  $userStory
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, UserStory $userstory)
    {
       
        $userstory->user_story=$request->user_story;
        $userstory->desc_story=$request->desc_story;
        $userstory->prio_story=$request->prio_story;
        $userstory->workflow=$request->workflow;
        $userstory->save();
        $mappings = new Mapping();
        
        $secfeatures = $request->secfeature_id;
           
                foreach($mappings as $mapping)
                {
                    $mapping = new Mapping();
                    $mapping->ustory_id=$request->u_id;
                    $mapping->type_NFR= 1;
                    $mapping->id_NFR=$secfeatures; 
                    $mapping->save();
                }
                
                
        $perfeatures = $request->perfeature_id;    
                
                foreach($mappings as $mapping2)
                {
                    $mapping2 = new Mapping();
                    $mapping2->ustory_id=$request->u_id;
                    $mapping2->type_NFR= 2;
                    $mapping2->id_NFR=$perfeatures; 
                    $mapping2->save();
                }
 
       return redirect()->route('profeature.index3',$userstory);

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\UserStory  $userStory
     * @return \Illuminate\Http\Response
     */
    public function destroy(UserStory $userStory)
    {
        
    }
}
