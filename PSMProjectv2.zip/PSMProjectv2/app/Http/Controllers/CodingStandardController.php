<?php

namespace App\Http\Controllers;
use App\Project;
use App\CodingStandard;
use Illuminate\Http\Request;

class CodingStandardController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $project = new Project();
        $codestand = new CodingStandard();
        //return view('sprint.create',['projects'=> $project->all(), 'users'=> $user->all()]);
        return view ('codestand.index', ['codestands'=>$codestand->all(), 'projects'=>$project->all()]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $project = new Project();
        return view('codestand.create',['projects'=>$project->all()]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $codestand = new CodingStandard;
        $codestand->codestand_name=$request->codestand_name;
        $sprint->save();
        return redirect()->route('codestand.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\CodingStandard  $codingStandard
     * @return \Illuminate\Http\Response
     */
    public function show(CodingStandard $codingStandard)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\CodingStandard  $codingStandard
     * @return \Illuminate\Http\Response
     */
    public function edit(CodingStandard $codingStandard)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\CodingStandard  $codingStandard
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CodingStandard $codingStandard)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\CodingStandard  $codingStandard
     * @return \Illuminate\Http\Response
     */
    public function destroy(CodingStandard $codingStandard)
    {
        //
    }
}
