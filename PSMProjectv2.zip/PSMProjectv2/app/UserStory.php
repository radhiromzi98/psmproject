<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserStory extends Model
{
    protected $fillable = ['user_story','desc_story','perf_feature','secure_feature','defect_feature','prio_story','workflow'];

    public $primaryKey = 'u_id';

    public $foreignKey = 'sprint_id';
}
