-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 17, 2019 at 05:45 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--------------------------------------------------------



----------------------------------------------------------

--
-- Table structure for table `mappings`
--

CREATE TABLE `mappings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ustory_id` int(11) NOT NULL,
  `type_NFR` int(11) NOT NULL,
  `id_NFR` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mappings`
--

INSERT INTO `mappings` (`id`, `ustory_id`, `type_NFR`, `id_NFR`, `created_at`, `updated_at`) VALUES
(11, 1, 1, 2, '2019-06-29 08:46:54', '2019-06-29 08:46:54'),
(12, 1, 2, 3, '2019-06-29 08:46:54', '2019-06-29 08:46:54'),
(13, 1, 2, 4, '2019-06-29 08:46:54', '2019-06-29 08:46:54');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_03_16_084930_create_roles_table', 1),
(4, '2019_03_27_154105_create_projects_table', 1),
(5, '2019_04_11_160005_create_sprint_table', 1),
(6, '2019_05_03_065013_create_user_stories_table', 1),
(7, '2019_05_05_171853_create_priorities_table', 1),
(8, '2019_05_05_174636_create_security_features_table', 1),
(9, '2019_05_07_143235_create_performance_features_table', 1),
(10, '2019_05_09_031717_create_product_features_table', 1),
(11, '2019_05_09_160910_create_workflow_steps_table', 1),
(12, '2019_05_26_175447_create_coding_standards_table', 2),
(13, '2019_05_26_195719_create_defect_features_table', 3),
(14, '2019_06_18_135421_add_proj_name_to_user_stories', 3),
(15, '2019_06_20_024827_add_user_id_to_projects_table', 4),
(16, '2019_06_21_055953_create_mapping_table', 5),
(17, '2019_06_21_162715_add_sprint_id_to_user_stories_table', 6),
(18, '2019_06_29_162615_create_mapping_table', 7),
(19, '2019_06_29_163059_create_mappings_table', 8);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `performance_features`
--

CREATE TABLE `performance_features` (
  `perfeature_id` bigint(20) UNSIGNED NOT NULL,
  `perfeature_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `performance_features`
--

INSERT INTO `performance_features` (`perfeature_id`, `perfeature_name`, `created_at`, `updated_at`) VALUES
(1, 'Loading Time', '2019-05-26 10:47:18', '2019-05-26 10:47:18'),
(2, 'Buffering Time', '2019-05-26 10:47:35', '2019-05-26 10:47:35'),
(3, 'Response Time', '2019-05-26 10:47:53', '2019-05-26 10:47:53'),
(4, 'Time Latency', '2019-05-26 10:48:06', '2019-05-26 10:48:06');

-- --------------------------------------------------------

--
-- Table structure for table `priorities`
--

CREATE TABLE `priorities` (
  `prio_id` bigint(20) UNSIGNED NOT NULL,
  `prio_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priorities`
--

INSERT INTO `priorities` (`prio_id`, `prio_name`, `created_at`, `updated_at`) VALUES
(1, 'High', NULL, NULL),
(2, 'Medium', NULL, NULL),
(3, 'Low', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_features`
--

CREATE TABLE `product_features` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `profeature_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `proj_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `proj_desc` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `proj_name`, `proj_desc`, `start_date`, `end_date`, `created_at`, `updated_at`, `user_id`) VALUES
(1, 'Game of Throne', 'This game is propose by ABC company', '2019-04-01', '2019-07-31', '2019-05-26 06:45:27', '2019-06-29 07:20:50', 8),
(3, 'Food Grab', 'new application for delivery ordering system', '2019-03-28', '2019-09-30', '2019-05-26 09:17:53', '2019-05-26 19:11:01', 7),
(4, 'bubu', 'cooking game', '2019-02-13', '2019-10-31', '2019-05-26 19:26:10', '2019-06-18 22:01:10', 2),
(5, 'Battleship Island', 'peranggg', '2019-06-28', '2019-07-26', '2019-06-19 19:16:13', '2019-06-19 19:16:13', 7),
(6, 'Face Mapping System', 'system to check on face condition', '2019-06-27', '2019-08-31', '2019-06-20 12:25:33', '2019-06-20 12:25:33', 8);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `role_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role_name`, `created_at`, `updated_at`) VALUES
(1, 'Project Manager', NULL, NULL),
(2, 'Scrum Master', NULL, NULL),
(3, 'Software Tester', NULL, NULL),
(4, 'Chief Programmer', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `security_features`
--

CREATE TABLE `security_features` (
  `SecFeature_id` bigint(20) UNSIGNED NOT NULL,
  `secfeature_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secfeature_desc` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `security_features`
--

INSERT INTO `security_features` (`SecFeature_id`, `secfeature_name`, `secfeature_desc`, `created_at`, `updated_at`) VALUES
(1, 'SQL Injection', 'Avoid any hacker', '2019-05-26 10:48:52', '2019-05-26 10:48:52'),
(2, 'Cross_Site Scripting', 'Malicious scripts', '2019-05-26 10:49:59', '2019-05-26 10:49:59'),
(3, 'Database Hacking', 'Thread on database', '2019-05-26 10:50:53', '2019-05-26 10:50:53');

-- --------------------------------------------------------

--
-- Table structure for table `sprint`
--

CREATE TABLE `sprint` (
  `sprint_id` bigint(20) UNSIGNED NOT NULL,
  `sprint_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sprint_desc` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_sprint` date NOT NULL,
  `end_sprint` date NOT NULL,
  `proj_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `users_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sprint`
--

INSERT INTO `sprint` (`sprint_id`, `sprint_name`, `sprint_desc`, `start_sprint`, `end_sprint`, `proj_name`, `users_name`, `created_at`, `updated_at`) VALUES
(1, 'sprint 1', 'task should be complete within 1 month', '2019-05-13', '2019-06-27', 'Game of Throne', 'maziah', '2019-05-26 08:29:45', '2019-06-20 13:19:37'),
(2, 'sprint 1', '5 user stories should finish within the time', '2019-05-15', '2019-05-30', 'Food Grab', 'maziah', '2019-05-26 09:24:54', '2019-06-21 04:22:17'),
(3, 'sprint 1', 'task should be complete within 1 month', '2019-06-04', '2019-06-30', 'bubu game', 'maziah', '2019-05-26 19:28:59', '2019-05-26 19:28:59'),
(4, 'sprint 2', 'within 2 month', '2019-06-05', '2019-06-28', 'Game of Throne', 'Anis', '2019-05-26 20:34:19', '2019-05-26 20:34:19'),
(5, 'sprint 1', 'battleship island first sprint to be started', '2019-06-22', '2019-06-30', 'Battleship Island', 'suHana', '2019-06-20 02:28:06', '2019-06-20 03:26:22'),
(6, 'sprint 1', 'at least 2 feature should be include', '2019-06-24', '2019-07-31', 'Face Mapping System', 'maziah99', '2019-06-20 12:57:52', '2019-06-20 13:18:24'),
(9, 'sprint 2', 'battleship island second sprint to be started', '2019-06-27', '2019-07-31', 'Battleship Island', 'maziah99', '2019-06-21 03:22:51', '2019-06-21 03:22:51'),
(10, 'sprint 2', 'kijnoim', '2019-06-28', '2019-07-05', 'Face Mapping System', 'suHana', '2019-06-21 03:40:43', '2019-06-21 03:40:43'),
(11, 'sprint 2', 'whatever', '2019-06-26', '2019-07-26', 'Face Mapping System', 'maziah99', '2019-06-21 03:48:39', '2019-06-21 03:48:39'),
(12, 'sprint 3', 'sdcsdc', '2019-06-29', '2019-07-18', 'Face Mapping System', 'maziah', '2019-06-21 03:50:47', '2019-06-21 03:50:47'),
(16, 'sprint 2', 'sacxsdzczd', '2019-06-26', '2019-07-24', 'Food Grab', 'maziah', '2019-06-21 04:11:03', '2019-06-21 04:11:03'),
(17, 'sprint 3', 'kijnoim', '2019-06-26', '2019-07-11', 'Game of Throne', 'Anis', '2019-06-21 04:32:21', '2019-06-21 04:32:21'),
(19, 'sprint 4', 'whateversnjefcodncfobv', '2019-07-26', '2019-07-31', 'Game of Throne', 'Anis', '2019-06-21 04:37:35', '2019-06-21 04:37:35'),
(21, 'sprint 5', 'bmzhsbendhijdcf', '2019-06-25', '2019-07-25', 'Game of Throne', 'suHana', '2019-06-21 04:47:46', '2019-06-21 04:47:46'),
(22, 'sprint 3', 'kdakmcxnsdbhvc', '2019-06-28', '2019-07-04', 'Face Mapping System', 'suHana', '2019-06-21 05:06:28', '2019-06-21 05:06:28'),
(23, 'sprint 3', 'create interface', '2019-06-26', '2019-07-17', 'Food Grab', 'Anis', '2019-06-21 05:10:20', '2019-06-21 05:10:20');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `role`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'NUR MAZIAH BT MOHD RUSLI', 'maziah', 'Chief Programmer', 'nutmaziah.9759@gmail.com', NULL, '$2y$10$c8nkdBC7D7rAdj0OB71XWu4P1KQYfhOjNmHXHN8gWcsQKjgiami/S', NULL, '2019-05-26 05:23:43', '2019-05-26 05:23:43'),
(2, 'ANIS SYAHIRAH BINTI AHMAD', 'Anis', 'Chief Programmer', 'anis97@gmail.com', NULL, '$2y$10$zRPPRr7xSnv/gn5o7C5HfeKyWe19WDJZFk4tkFKDvWm147.hosI3i', NULL, '2019-05-26 09:42:24', '2019-05-26 09:42:24'),
(7, 'Salsabila Hana', 'suHana', 'Chief Programmer', 'salsa98@gmail.com', NULL, '$2y$10$o92iRnidWyWZLRYb53W1HOHoNjCjNZyT5zu4cT/4tjo9G6oBKxq0G', NULL, '2019-06-19 17:46:44', '2019-06-19 17:46:44'),
(8, 'maziah rusli', 'maziah99', 'Project Manager', 'maziah99@gmail.com', NULL, '$2y$10$yECL.188RMhEMoeaz.DiUu7OQAt0FNuRS9U2mAkLRFT53xdaQmb0G', NULL, '2019-06-19 19:34:44', '2019-06-19 19:34:44');

-- --------------------------------------------------------

--
-- Table structure for table `user_stories`
--

CREATE TABLE `user_stories` (
  `u_id` bigint(20) UNSIGNED NOT NULL,
  `user_story` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc_story` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prio_story` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `workflow` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `sprint_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_stories`
--

INSERT INTO `user_stories` (`u_id`, `user_story`, `desc_story`, `prio_story`, `workflow`, `created_at`, `updated_at`, `sprint_id`) VALUES
(1, 'saya lapar', 'saya nak makan', 'Medium', 'New Request', '2019-05-26 18:41:30', '2019-06-29 07:05:19', 1),
(2, 'Hand-free Module', 'Add a new gaming experience', 'Medium', 'Approved', '2019-05-26 19:51:06', '2019-06-20 02:24:50', 1),
(3, 'sawetf', 'adfgrg', 'High', 'In Progress', '2019-05-26 23:17:06', '2019-05-26 23:17:06', 4);

-- --------------------------------------------------------

--
-- Table structure for table `workflow_steps`
--

CREATE TABLE `workflow_steps` (
  `wflow_id` bigint(20) UNSIGNED NOT NULL,
  `workflow_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `workflow_steps`
--

INSERT INTO `workflow_steps` (`wflow_id`, `workflow_name`, `created_at`, `updated_at`) VALUES
(1, 'New Request', NULL, NULL),
(2, 'Approved', NULL, NULL),
(3, 'In Progress', NULL, NULL),
(4, 'Ready For Testing', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `coding_standards`
--
ALTER TABLE `coding_standards`
  ADD PRIMARY KEY (`codestand_id`);

--
-- Indexes for table `defect_features`
--
ALTER TABLE `defect_features`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mappings`
--
ALTER TABLE `mappings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `performance_features`
--
ALTER TABLE `performance_features`
  ADD PRIMARY KEY (`perfeature_id`);

--
-- Indexes for table `priorities`
--
ALTER TABLE `priorities`
  ADD PRIMARY KEY (`prio_id`);

--
-- Indexes for table `product_features`
--
ALTER TABLE `product_features`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `security_features`
--
ALTER TABLE `security_features`
  ADD PRIMARY KEY (`SecFeature_id`);

--
-- Indexes for table `sprint`
--
ALTER TABLE `sprint`
  ADD PRIMARY KEY (`sprint_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_username_unique` (`username`);

--
-- Indexes for table `user_stories`
--
ALTER TABLE `user_stories`
  ADD PRIMARY KEY (`u_id`);

--
-- Indexes for table `workflow_steps`
--
ALTER TABLE `workflow_steps`
  ADD PRIMARY KEY (`wflow_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `coding_standards`
--
ALTER TABLE `coding_standards`
  MODIFY `codestand_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `defect_features`
--
ALTER TABLE `defect_features`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mappings`
--
ALTER TABLE `mappings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `performance_features`
--
ALTER TABLE `performance_features`
  MODIFY `perfeature_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `priorities`
--
ALTER TABLE `priorities`
  MODIFY `prio_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `product_features`
--
ALTER TABLE `product_features`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `security_features`
--
ALTER TABLE `security_features`
  MODIFY `SecFeature_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sprint`
--
ALTER TABLE `sprint`
  MODIFY `sprint_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user_stories`
--
ALTER TABLE `user_stories`
  MODIFY `u_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `workflow_steps`
--
ALTER TABLE `workflow_steps`
  MODIFY `wflow_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
